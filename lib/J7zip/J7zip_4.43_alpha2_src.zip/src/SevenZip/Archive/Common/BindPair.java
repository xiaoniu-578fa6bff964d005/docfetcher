package SevenZip.Archive.Common;

public class BindPair {
    public int InIndex;
    public int OutIndex;
    
    public BindPair() {
        InIndex = 0;
        OutIndex = 0;
    }
}

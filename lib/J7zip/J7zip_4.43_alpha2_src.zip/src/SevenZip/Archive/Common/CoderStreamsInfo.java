package SevenZip.Archive.Common;

public class CoderStreamsInfo {
    public int NumInStreams;
    public int NumOutStreams;
    
    public CoderStreamsInfo() {
        NumInStreams = 0;
        NumOutStreams = 0;
    }
}

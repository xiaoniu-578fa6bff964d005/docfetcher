package SevenZip;

public interface ICompressGetInStreamProcessedSize {
    public long GetInStreamProcessedSize();
}


/**
 * 
 */
package com.pff;

/**
 * Items found in the 7c tables
 * @author Richard Johnson
 */
class PSTTable7CItem extends PSTTableItem
{
	
	public String toString() {
		return "7c Table Item: " + super.toString() + "\n";
	}
}
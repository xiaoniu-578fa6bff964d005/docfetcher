/**
 * 
 */
package com.pff;

/**
 * Items within the BC Table
 * @author Richard Johnson
 */
class PSTTableBCItem extends PSTTableItem
{

	public String toString() {
		return "Table Item: "+super.toString() + "\n";
	}
}
